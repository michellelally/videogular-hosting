export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAfzxsONF5agbyZwL5ziKye5YCsy7gQ2Zk",
    authDomain: "ppit-436ab.firebaseapp.com",
    databaseURL: "https://ppit-436ab.firebaseio.com",
    projectId: "ppit-436ab",
    storageBucket: "ppit-436ab.appspot.com",
    messagingSenderId: "1065215763712"

  }
};
